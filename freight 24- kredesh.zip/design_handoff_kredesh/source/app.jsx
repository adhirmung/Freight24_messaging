// Main app — auth gate + routing
function App() {
  const D = window.KredeshData;
  const me = D.users.find(u => u.isMe);

  const [auth, setAuth] = React.useState(() => {
    try { return localStorage.getItem('kredesh-auth') === '1'; } catch (e) { return false; }
  });
  const [route, setRoute] = React.useState(() => {
    try {
      const r = localStorage.getItem('kredesh-route');
      return r ? JSON.parse(r) : { screen: 'inbox', threadId: 't1' };
    } catch (e) { return { screen: 'inbox', threadId: 't1' }; }
  });

  React.useEffect(() => {
    try { localStorage.setItem('kredesh-route', JSON.stringify(route)); } catch (e) {}
  }, [route]);

  const signIn = () => {
    try { localStorage.setItem('kredesh-auth', '1'); } catch (e) {}
    setAuth(true);
  };
  const signOut = () => {
    try { localStorage.removeItem('kredesh-auth'); } catch (e) {}
    setAuth(false);
  };
  window.__signOut = signOut;

  if (!auth) {
    return <AuthScreen onAuth={signIn} />;
  }

  // command palette
  const [paletteOpen, setPaletteOpen] = React.useState(false);
  React.useEffect(() => {
    const h = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen(p => !p);
      }
      if (e.key === 'Escape') setPaletteOpen(false);
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  let body = null;
  switch (route.screen) {
    case 'inbox':         body = <InboxScreen route={route} setRoute={setRoute} user={me} />; break;
    case 'tasks':         body = <TasksScreen route={route} setRoute={setRoute} user={me} />; break;
    case 'shipments':     body = <ShipmentsScreen route={route} setRoute={setRoute} />; break;
    case 'notifications': body = <NotificationsScreen />; break;
    case 'reports':       body = <ReportsScreen />; break;
    case 'settings':      body = <SettingsScreen user={me} />; break;
    case 'admin':         body = <AdminScreen />; break;
    case 'driver':        body = <DriverScreen />; break;
    default:              body = <InboxScreen route={route} setRoute={setRoute} user={me} />;
  }

  return (
    <div style={{
      display: 'flex', height: '100vh',
      background: 'var(--bg-0)', color: 'var(--ink-0)',
      overflow: 'hidden',
    }}>
      <Sidebar route={route} setRoute={setRoute} user={me} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden' }}>
        {body}
      </div>
      {paletteOpen && <CommandPalette onClose={() => setPaletteOpen(false)} setRoute={setRoute} />}
    </div>
  );
}

function CommandPalette({ onClose, setRoute }) {
  const D = window.KredeshData;
  const [q, setQ] = React.useState('');
  const all = [
    ...D.threads.map(t => ({ kind: 'Thread', id: t.id, title: t.title, sub: t.preview, go: () => setRoute({ screen: 'inbox', threadId: t.id }) })),
    ...D.shipments.map(s => ({ kind: 'Shipment', id: s.id, title: s.pro + ' · ' + s.customer, sub: s.origin + ' → ' + s.dest, go: () => setRoute({ screen: 'shipments', shipmentId: s.id }) })),
    ...D.tasks.map(t => ({ kind: 'Task', id: t.id, title: t.title, sub: 'Source: ' + t.source, go: () => setRoute({ screen: 'tasks' }) })),
    { kind: 'Nav', id: 'admin', title: 'Admin · User management', sub: 'Manage employees, invites, roles', go: () => setRoute({ screen: 'admin' }) },
    { kind: 'Nav', id: 'driver', title: 'Mobile · Driver app', sub: 'Preview the on-truck experience', go: () => setRoute({ screen: 'driver' }) },
    { kind: 'Nav', id: 'reports', title: 'Reports', sub: 'KPIs, extraction quality, lanes', go: () => setRoute({ screen: 'reports' }) },
  ];
  const filtered = q ? all.filter(x => (x.title + x.sub).toLowerCase().includes(q.toLowerCase())) : all.slice(0, 8);

  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, background: 'rgba(7,11,20,0.6)',
      backdropFilter: 'blur(3px)', display: 'grid', placeItems: 'start center',
      zIndex: 60, paddingTop: 100,
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: 'min(580px, 92%)',
        background: 'var(--bg-1)', border: '1px solid var(--line-2)',
        borderRadius: 14, overflow: 'hidden',
        boxShadow: '0 30px 80px rgba(0,0,0,0.6)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '13px 16px', borderBottom: '1px solid var(--line)' }}>
          <Icons.search size={16} stroke="var(--ink-3)" />
          <input autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="Search threads, shipments, tasks, navigate…" style={{
            flex: 1, background: 'none', border: 'none', color: 'var(--ink-0)', fontSize: 15, outline: 'none',
          }} />
          <span className="kbd">esc</span>
        </div>
        <div style={{ maxHeight: 380, overflow: 'auto', padding: 6 }}>
          {filtered.slice(0, 12).map((r, i) => (
            <button key={r.kind + r.id} onClick={() => { r.go(); onClose(); }} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 12,
              padding: '10px 12px', background: 'transparent', border: 'none',
              borderRadius: 8, textAlign: 'left', cursor: 'pointer', color: 'var(--ink-0)',
            }} onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-3)'}
               onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
              <span className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, width: 70 }}>{r.kind}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.title}</div>
                <div style={{ fontSize: 11.5, color: 'var(--ink-3)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.sub}</div>
              </div>
              <Icons.arrow size={13} stroke="var(--ink-3)" />
            </button>
          ))}
          {filtered.length === 0 && <div style={{ padding: 30, textAlign: 'center', color: 'var(--ink-3)' }}>No matches.</div>}
        </div>
        <div style={{ padding: '8px 14px', borderTop: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 12, fontSize: 10.5, color: 'var(--ink-3)' }}>
          <span><span className="kbd">↵</span> open</span>
          <span><span className="kbd">↑↓</span> move</span>
          <div style={{ flex: 1 }} />
          <span>Kredesh · ⌘K</span>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
