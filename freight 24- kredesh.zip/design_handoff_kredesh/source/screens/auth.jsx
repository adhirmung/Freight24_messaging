// Auth — sign in + invite acceptance
function AuthScreen({ onAuth }) {
  const [mode, setMode] = React.useState('signin'); // 'signin' | 'invite'
  const [email, setEmail] = React.useState('avery.chen@kredesh.co');
  const [pwd, setPwd]   = React.useState('••••••••••');
  const [showPwd, setShowPwd] = React.useState(false);
  const [name, setName] = React.useState('');
  const [pwd2, setPwd2] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  const [err, setErr]   = React.useState('');
  const [mfa, setMfa]   = React.useState(false);
  const [code, setCode] = React.useState(['', '', '', '', '', '']);

  const submit = (e) => {
    e?.preventDefault();
    setErr('');
    if (mode === 'signin') {
      if (!email.includes('@')) return setErr('Enter your work email.');
      if (pwd.length < 4) return setErr('Password is too short.');
      setBusy(true);
      setTimeout(() => { setBusy(false); setMfa(true); }, 700);
    } else {
      if (!name.trim()) return setErr('Tell us your full name.');
      if (pwd.length < 8) return setErr('Choose a password of at least 8 characters.');
      if (pwd !== pwd2) return setErr('Passwords don\'t match.');
      setBusy(true);
      setTimeout(() => { setBusy(false); onAuth(); }, 800);
    }
  };

  const submitMfa = () => {
    if (code.join('').length < 6) return setErr('Enter the 6‑digit code.');
    setBusy(true);
    setTimeout(() => { setBusy(false); onAuth(); }, 500);
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg-0)',
      display: 'grid', gridTemplateColumns: 'minmax(0, 1.15fr) minmax(420px, 1fr)',
    }}>
      {/* Left — brand panel */}
      <div style={{
        position: 'relative', overflow: 'hidden',
        background: 'radial-gradient(120% 80% at 20% 20%, rgba(59,130,246,0.18), transparent 60%), radial-gradient(80% 70% at 90% 90%, rgba(34,211,238,0.14), transparent 60%), #0A1020',
        borderRight: '1px solid var(--line)',
        display: 'flex', flexDirection: 'column',
        padding: '36px 44px 32px',
        gap: 28,
      }}>
        <BrandHeader />

        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', maxWidth: 520 }}>
          <div className="mono" style={{ fontSize: 11, color: '#67E8F9', letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: 18 }}>
            <span className="live-dot" style={{ display: 'inline-block', marginRight: 8, verticalAlign: 1 }} />
            Live operations · 18 active loads
          </div>
          <h1 style={{
            margin: 0, fontFamily: 'var(--display)', fontWeight: 400,
            fontSize: 'clamp(40px, 5.2vw, 60px)', lineHeight: 1.02, letterSpacing: -1.0,
            color: 'var(--ink-0)',
          }}>
            The signal between<br/>
            the <span style={{ color: '#67E8F9' }}>warehouse</span><br/>
            and the road.
          </h1>
          <p style={{ marginTop: 22, color: 'var(--ink-2)', fontSize: 14.5, lineHeight: 1.55, maxWidth: 460 }}>
            Kredesh turns every dispatch message into structured shipment data — PROs, addresses,
            equipment, time windows — and routes the work to whoever should close it.
          </p>
        </div>

        <LiveTicker />
      </div>

      {/* Right — form */}
      <div style={{ display: 'grid', placeItems: 'center', padding: 40 }}>
        <div style={{ width: '100%', maxWidth: 420 }}>
          <div style={{ display: 'flex', gap: 4, padding: 4, background: 'var(--bg-2)', border: '1px solid var(--line)', borderRadius: 10, marginBottom: 24 }}>
            {[
              { id: 'signin', label: 'Sign in' },
              { id: 'invite', label: 'Accept invite' },
            ].map(o => (
              <button key={o.id}
                onClick={() => { setMode(o.id); setErr(''); setMfa(false); }}
                style={{
                  flex: 1, padding: '7px 10px',
                  background: mode === o.id ? 'var(--bg-3)' : 'transparent',
                  color: mode === o.id ? 'var(--ink-0)' : 'var(--ink-2)',
                  border: '1px solid', borderColor: mode === o.id ? 'var(--line-2)' : 'transparent',
                  borderRadius: 7, fontSize: 13, fontWeight: 600,
                }}>{o.label}</button>
            ))}
          </div>

          {!mfa && mode === 'signin' && (
            <form onSubmit={submit}>
              <h2 style={{ margin: '0 0 6px', fontSize: 22, fontWeight: 600, letterSpacing: -0.3 }}>Welcome back</h2>
              <p style={{ margin: '0 0 22px', color: 'var(--ink-2)', fontSize: 13.5 }}>Sign in with your <span className="mono" style={{ color: 'var(--ink-1)' }}>@kredesh.co</span> account.</p>

              <Field label="Work email" icon={<Icons.mail size={14} stroke="var(--ink-3)" />}>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" />
              </Field>
              <Field label="Password" icon={<Icons.lock size={14} stroke="var(--ink-3)" />}
                right={<button type="button" onClick={() => setShowPwd(s => !s)} style={{ background: 'none', border: 'none', color: 'var(--ink-3)', padding: 2 }}><Icons.eye size={14}/></button>}>
                <input type={showPwd ? 'text' : 'password'} value={pwd} onChange={e => setPwd(e.target.value)} autoComplete="current-password" />
              </Field>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, fontSize: 12.5 }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: 7, color: 'var(--ink-2)' }}>
                  <input type="checkbox" defaultChecked style={{ accentColor: 'var(--brand)' }} /> Keep me signed in
                </label>
                <a href="#" style={{ color: '#93C5FD', textDecoration: 'none' }}>Forgot password?</a>
              </div>

              {err && <ErrMsg>{err}</ErrMsg>}

              <Btn primary size="lg" type="submit" style={{ width: '100%', justifyContent: 'center' }} disabled={busy}>
                {busy ? 'Signing in…' : <>Continue <Icons.arrow size={15} /></>}
              </Btn>

              <div style={{ margin: '22px 0', display: 'flex', alignItems: 'center', gap: 10, color: 'var(--ink-3)', fontSize: 11 }}>
                <div style={{ flex: 1, height: 1, background: 'var(--line)' }} />
                OR
                <div style={{ flex: 1, height: 1, background: 'var(--line)' }} />
              </div>
              <Btn size="lg" style={{ width: '100%', justifyContent: 'center' }} type="button" onClick={() => onAuth()}>
                <SSO /> Continue with Kredesh SSO
              </Btn>

              <p style={{ marginTop: 22, fontSize: 11.5, color: 'var(--ink-3)', textAlign: 'center', lineHeight: 1.6 }}>
                Internal employees only. Account access is provisioned by your administrator.<br/>
                By signing in you agree to the <a href="#" style={{ color: 'var(--ink-2)' }}>Acceptable Use Policy</a>.
              </p>
            </form>
          )}

          {!mfa && mode === 'invite' && (
            <form onSubmit={submit}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, padding: '8px 11px', background: 'var(--brand-soft)', border: '1px solid rgba(59,130,246,0.28)', borderRadius: 8 }}>
                <Icons.shield size={16} stroke="#93C5FD" />
                <div style={{ fontSize: 12.5, color: '#BFDBFE' }}>
                  Invited by <b>Maya Okafor</b> to join <b>Kredesh Freight Co.</b> as <b>Dispatcher</b>.
                </div>
              </div>
              <h2 style={{ margin: '0 0 6px', fontSize: 22, fontWeight: 600, letterSpacing: -0.3 }}>Set up your account</h2>
              <p style={{ margin: '0 0 22px', color: 'var(--ink-2)', fontSize: 13.5 }}>Welcome to the team. A few details and you're in.</p>

              <Field label="Work email" icon={<Icons.mail size={14} stroke="var(--ink-3)" />}>
                <input type="email" value="owen@kredesh.co" disabled style={{ color: 'var(--ink-2)' }} readOnly />
              </Field>
              <Field label="Full name" icon={<Icons.user size={14} stroke="var(--ink-3)" />}>
                <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Owen Tahan" autoFocus />
              </Field>
              <Field label="Password" icon={<Icons.lock size={14} stroke="var(--ink-3)" />}>
                <input type="password" value={pwd} onChange={e => setPwd(e.target.value)} placeholder="At least 8 characters" />
              </Field>
              <Field label="Confirm password" icon={<Icons.lock size={14} stroke="var(--ink-3)" />}>
                <input type="password" value={pwd2} onChange={e => setPwd2(e.target.value)} placeholder="Repeat password" />
              </Field>

              <label style={{ display: 'flex', alignItems: 'flex-start', gap: 9, fontSize: 12.5, color: 'var(--ink-2)', marginBottom: 18, lineHeight: 1.5 }}>
                <input type="checkbox" defaultChecked style={{ marginTop: 3, accentColor: 'var(--brand)' }} />
                I agree to the Kredesh <a href="#" style={{ color: '#93C5FD' }}>Employee Handbook</a> and <a href="#" style={{ color: '#93C5FD' }}>Data Handling Policy</a>.
              </label>

              {err && <ErrMsg>{err}</ErrMsg>}

              <Btn primary size="lg" type="submit" style={{ width: '100%', justifyContent: 'center' }} disabled={busy}>
                {busy ? 'Creating account…' : <>Create account <Icons.arrow size={15} /></>}
              </Btn>
            </form>
          )}

          {mfa && (
            <div>
              <h2 style={{ margin: '0 0 6px', fontSize: 22, fontWeight: 600, letterSpacing: -0.3 }}>Two‑factor verification</h2>
              <p style={{ margin: '0 0 22px', color: 'var(--ink-2)', fontSize: 13.5 }}>
                Enter the 6‑digit code from your authenticator app.
              </p>

              <div style={{ display: 'flex', gap: 8, justifyContent: 'space-between', marginBottom: 18 }}>
                {code.map((c, i) => (
                  <input key={i} value={c}
                    onChange={e => {
                      const v = e.target.value.replace(/\D/g, '').slice(-1);
                      const next = [...code]; next[i] = v; setCode(next);
                      if (v) {
                        const el = document.querySelectorAll('[data-mfa]')[i + 1];
                        el?.focus();
                      }
                    }}
                    data-mfa
                    maxLength={1}
                    style={{
                      width: 52, height: 60, textAlign: 'center',
                      fontFamily: 'var(--mono)', fontSize: 26, fontWeight: 600,
                      background: 'var(--bg-2)', border: '1px solid var(--line-2)',
                      borderRadius: 10, color: 'var(--ink-0)',
                      outline: 'none',
                    }} />
                ))}
              </div>

              {err && <ErrMsg>{err}</ErrMsg>}

              <Btn primary size="lg" onClick={submitMfa} style={{ width: '100%', justifyContent: 'center' }} disabled={busy}>
                {busy ? 'Verifying…' : <>Verify & continue <Icons.arrow size={15} /></>}
              </Btn>
              <button onClick={() => setCode(['1','2','3','4','5','6'])} style={{ marginTop: 14, background: 'none', border: 'none', color: 'var(--ink-3)', fontSize: 12, width: '100%' }}>
                Try demo code →
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, icon, right, children }) {
  return (
    <label style={{ display: 'block', marginBottom: 14 }}>
      <div style={{ fontSize: 11.5, fontWeight: 600, color: 'var(--ink-2)', marginBottom: 6, letterSpacing: 0.2, textTransform: 'uppercase' }}>{label}</div>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '10px 12px',
        background: 'var(--bg-2)', border: '1px solid var(--line-2)',
        borderRadius: 9,
      }}>
        {icon}
        {React.Children.map(children, ch => React.cloneElement(ch, {
          style: { flex: 1, background: 'none', border: 'none', outline: 'none', color: 'var(--ink-0)', fontSize: 14, ...(ch.props.style || {}) }
        }))}
        {right}
      </div>
    </label>
  );
}

function ErrMsg({ children }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '8px 11px', marginBottom: 14,
      background: 'var(--bad-soft)', border: '1px solid rgba(239,68,68,0.32)',
      borderRadius: 8, color: '#FCA5A5', fontSize: 12.5,
    }}>
      <Icons.warn size={14} stroke="#FCA5A5" /> {children}
    </div>
  );
}

function SSO() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M3 6h8M3 8h6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
      <rect x="1" y="2" width="12" height="10" rx="2" stroke="currentColor" strokeWidth="1.4"/>
    </svg>
  );
}

function BrandHeader() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
      <div style={{
        width: 34, height: 34, borderRadius: 8,
        background: 'linear-gradient(135deg, #3B82F6, #22D3EE)',
        display: 'grid', placeItems: 'center',
        boxShadow: '0 0 0 1px rgba(255,255,255,0.06), 0 4px 20px rgba(59,130,246,0.35)',
      }}>
        <svg width="18" height="18" viewBox="0 0 14 14" fill="none">
          <path d="M2 10h7l3-3-3-3H2v6Z" stroke="#fff" strokeWidth="1.6" strokeLinejoin="round"/>
          <circle cx="4.5" cy="11.5" r="1" fill="#fff"/>
          <circle cx="10" cy="11.5" r="1" fill="#fff"/>
        </svg>
      </div>
      <div>
        <div style={{ fontWeight: 700, fontSize: 17, letterSpacing: -0.3 }}>Kredesh</div>
        <div className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', letterSpacing: 0.8, textTransform: 'uppercase' }}>Logistics OS</div>
      </div>
    </div>
  );
}

function LiveTicker() {
  const items = [
    { code: 'PRO 778‑441920', stage: 'In transit',  loc: 'Tualatin → Portland', tone: 'cyan' },
    { code: 'PRO 882‑009417', stage: 'Reroute',     loc: 'I‑84 closure',         tone: 'warn' },
    { code: 'PRO 110‑772083', stage: 'Delivered',   loc: 'Seattle • POD signed', tone: 'ok'   },
    { code: 'PRO 992‑118044', stage: 'At pickup',   loc: 'Reno DC',              tone: 'blue' },
  ];
  return (
    <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', letterSpacing: 0.8, textTransform: 'uppercase' }}>Recent activity</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        {items.map((it, i) => (
          <div key={i} style={{
            padding: '10px 12px',
            background: 'rgba(15,23,42,0.6)', border: '1px solid var(--line)',
            borderRadius: 9, backdropFilter: 'blur(8px)',
            display: 'flex', flexDirection: 'column', gap: 4,
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="mono" style={{ fontSize: 11, color: 'var(--ink-1)' }}>{it.code}</span>
              <Pill tone={it.tone}>{it.stage}</Pill>
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>{it.loc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { AuthScreen });
