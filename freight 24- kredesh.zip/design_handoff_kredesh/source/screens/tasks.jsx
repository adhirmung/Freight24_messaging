// Tasks board — Complete / Pending / Incomplete
function TasksScreen({ route, setRoute, user }) {
  const D = window.KredeshData;
  const [tab, setTab] = React.useState('pending'); // pending | complete | incomplete
  const [view, setView] = React.useState('list'); // list | board
  const [tasks, setTasks] = React.useState(D.tasks);
  const [selectedId, setSelectedId] = React.useState('tk3');
  const [filter, setFilter] = React.useState({ assignee: 'all', priority: 'all' });

  const counts = {
    pending: tasks.filter(t => t.status === 'pending').length,
    complete: tasks.filter(t => t.status === 'complete').length,
    incomplete: tasks.filter(t => t.status === 'incomplete').length,
  };
  const total = tasks.length;

  const visible = tasks.filter(t => t.status === tab)
    .filter(t => filter.assignee === 'all' || t.assignee === filter.assignee || (filter.assignee === 'me' && t.assignee === 'me'))
    .filter(t => filter.priority === 'all' || t.priority === filter.priority);

  const toggleStatus = (id) => {
    setTasks(ts => ts.map(t => t.id === id ? { ...t,
      status: t.status === 'complete' ? 'pending' : 'complete',
      completedAt: t.status === 'complete' ? null : 'Just now',
    } : t));
  };

  const selected = tasks.find(t => t.id === selectedId);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
      <TopBar
        title="Tasks"
        subtitle={`${total} total · auto-extracted from messaging`}
        right={(
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <SearchInput placeholder="Search tasks…" />
            <Btn size="sm" icon={<Icons.filter size={13} />}>Filters</Btn>
            <Btn primary size="sm" icon={<Icons.plus size={13} />}>New task</Btn>
          </div>
        )}
      />

      {/* Stat row */}
      <div style={{ padding: '14px 22px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, borderBottom: '1px solid var(--line)', background: 'var(--bg-1)' }}>
        <StatCard label="Active load tasks" value="14" delta="+3 since 9am" tone="brand" />
        <StatCard label="Completed today" value="22" delta="+4 from yesterday" tone="ok" />
        <StatCard label="Avg time-to-close" value="8.4m" delta="−2.1m WoW" tone="ok" />
        <StatCard label="Overdue" value="2" delta="needs attention" tone="bad" />
      </div>

      {/* Tabs */}
      <div style={{ padding: '0 22px', display: 'flex', alignItems: 'center', gap: 4, borderBottom: '1px solid var(--line)', background: 'var(--bg-1)' }}>
        {[
          { id: 'pending', label: 'Pending', tone: 'brand', count: counts.pending },
          { id: 'complete', label: 'Complete', tone: 'ok', count: counts.complete },
          { id: 'incomplete', label: 'Incomplete', tone: 'bad', count: counts.incomplete },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            style={{
              padding: '12px 4px',
              marginRight: 22,
              background: 'transparent', border: 'none',
              borderBottom: '2px solid',
              borderBottomColor: tab === t.id ? (t.tone === 'ok' ? 'var(--ok)' : t.tone === 'bad' ? 'var(--bad)' : 'var(--brand)') : 'transparent',
              color: tab === t.id ? 'var(--ink-0)' : 'var(--ink-2)',
              fontSize: 13.5, fontWeight: 600,
              display: 'inline-flex', alignItems: 'center', gap: 8,
            }}>
            {t.label}
            <span className="mono" style={{
              fontSize: 10.5, fontWeight: 700,
              padding: '1px 6px', borderRadius: 999,
              background: tab === t.id ? (t.tone === 'ok' ? 'var(--ok-soft)' : t.tone === 'bad' ? 'var(--bad-soft)' : 'var(--brand-soft)') : 'var(--bg-3)',
              color: tab === t.id ? (t.tone === 'ok' ? '#86EFAC' : t.tone === 'bad' ? '#FCA5A5' : '#93C5FD') : 'var(--ink-2)',
            }}>{t.count}</span>
          </button>
        ))}
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 4, padding: 3, background: 'var(--bg-2)', border: '1px solid var(--line)', borderRadius: 7, marginRight: 0 }}>
          {['list', 'board'].map(v => (
            <button key={v} onClick={() => setView(v)} style={{
              padding: '4px 10px', fontSize: 11, fontWeight: 600,
              background: view === v ? 'var(--bg-3)' : 'transparent',
              color: view === v ? 'var(--ink-0)' : 'var(--ink-2)',
              border: '1px solid', borderColor: view === v ? 'var(--line-2)' : 'transparent',
              borderRadius: 5, textTransform: 'capitalize',
            }}>{v}</button>
          ))}
        </div>
      </div>

      {/* Main task panel */}
      <div style={{ flex: 1, display: 'flex', minHeight: 0, background: 'var(--bg-0)' }}>
        <div style={{ flex: 1, overflow: 'auto', padding: '14px 22px' }}>
          {view === 'list' ? (
            <TaskTable tasks={visible} tab={tab} onToggle={toggleStatus} selectedId={selectedId} onSelect={setSelectedId} />
          ) : (
            <TaskBoard tasks={tasks.filter(t => t.status === tab)} tab={tab} onToggle={toggleStatus} onSelect={setSelectedId} />
          )}
          {visible.length === 0 && (
            <div style={{ padding: '60px 20px', textAlign: 'center', color: 'var(--ink-3)' }}>
              <Icons.tasks size={36} stroke="var(--ink-4)" />
              <div style={{ marginTop: 14, fontSize: 14, fontWeight: 600, color: 'var(--ink-2)' }}>Nothing in this lane</div>
              <div style={{ marginTop: 4, fontSize: 12.5 }}>Tasks appear here as soon as Kredesh extracts them from messages.</div>
            </div>
          )}
        </div>

        {/* Right detail panel */}
        {selected && <TaskDetailPanel t={selected} onToggle={() => toggleStatus(selected.id)} onJump={() => setRoute({ screen: 'inbox', threadId: selected.source })} />}
      </div>
    </div>
  );
}

function StatCard({ label, value, delta, tone }) {
  const colors = {
    brand: '#93C5FD', ok: '#86EFAC', bad: '#FCA5A5', warn: '#FCD34D'
  };
  return (
    <div style={{ padding: 14, background: 'var(--bg-2)', border: '1px solid var(--line)', borderRadius: 11 }}>
      <div className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.6 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 6 }}>
        <span className="mono" style={{ fontSize: 26, fontWeight: 600, color: 'var(--ink-0)', lineHeight: 1, letterSpacing: -0.5 }}>{value}</span>
        <span style={{ fontSize: 11.5, color: colors[tone] || 'var(--ink-2)' }}>{delta}</span>
      </div>
    </div>
  );
}

function TaskTable({ tasks, tab, onToggle, selectedId, onSelect }) {
  const D = window.KredeshData;
  return (
    <div className="card" style={{ overflow: 'hidden' }}>
      <div style={{
        display: 'grid', gridTemplateColumns: '28px 1fr 160px 130px 100px 90px 80px',
        gap: 12, padding: '10px 14px',
        background: 'var(--bg-1)', borderBottom: '1px solid var(--line)',
        fontSize: 10.5, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.6, fontFamily: 'var(--mono)',
      }}>
        <div></div>
        <div>Task</div>
        <div>Extracted from</div>
        <div>Due</div>
        <div>Assignee</div>
        <div>Source</div>
        <div>Priority</div>
      </div>
      {tasks.map(t => {
        const assignee = D.byId(D.users, t.assignee);
        const thread = D.threads.find(th => th.id === t.source);
        const active = selectedId === t.id;
        return (
          <div key={t.id}
            onClick={() => onSelect(t.id)}
            style={{
              display: 'grid', gridTemplateColumns: '28px 1fr 160px 130px 100px 90px 80px',
              gap: 12, padding: '11px 14px',
              borderBottom: '1px solid var(--line)',
              alignItems: 'center', cursor: 'pointer',
              background: active ? 'var(--bg-3)' : 'transparent',
            }}>
            <TaskCheckbox status={t.status} onClick={(e) => { e?.stopPropagation?.(); onToggle(t.id); }} />
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: t.status === 'complete' ? 'var(--ink-2)' : 'var(--ink-0)', textDecoration: t.status === 'complete' ? 'line-through' : 'none' }}>
                {t.title}
              </div>
              {t.overdue && <div style={{ fontSize: 11, color: '#FCA5A5', marginTop: 2, display: 'inline-flex', alignItems: 'center', gap: 5 }}><Icons.warn size={11} stroke="#FCA5A5"/> Overdue — needs reassignment</div>}
              {t.completedAt && <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>Closed {t.completedAt}</div>}
            </div>
            <div style={{ fontSize: 11.5, color: 'var(--ink-2)' }}>
              <span className="chip" style={{ pointerEvents: 'none' }}>{t.extractedFrom || '—'}</span>
            </div>
            <div className="mono" style={{ fontSize: 11.5, color: t.overdue ? '#FCA5A5' : 'var(--ink-1)' }}>{t.due}</div>
            <div>{assignee && <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><Avatar user={assignee} size={20} /><span style={{ fontSize: 11.5, color: 'var(--ink-1)' }}>{assignee.initials}</span></div>}</div>
            <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>
              {thread ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><Icons.link size={11} stroke="var(--ink-3)" />{thread.title.split(' — ')[0].slice(0, 16)}</span> : '—'}
            </div>
            <div><PriorityPill p={t.priority} /></div>
          </div>
        );
      })}
    </div>
  );
}

function PriorityPill({ p }) {
  if (p === 'high') return <Pill tone="bad">High</Pill>;
  if (p === 'med')  return <Pill tone="warn">Med</Pill>;
  return <Pill>Low</Pill>;
}

function TaskBoard({ tasks, tab, onToggle, onSelect }) {
  // group by assignee/team
  const D = window.KredeshData;
  const groups = {};
  tasks.forEach(t => {
    const a = D.byId(D.users, t.assignee);
    const key = a?.team || 'Unassigned';
    (groups[key] ||= []).push(t);
  });
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 14 }}>
      {Object.entries(groups).map(([team, items]) => (
        <div key={team} className="card" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 12, fontWeight: 600 }}>{team}</span>
            <span className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>{items.length}</span>
          </div>
          {items.map(t => {
            const a = D.byId(D.users, t.assignee);
            return (
              <div key={t.id} onClick={() => onSelect(t.id)} style={{ padding: 10, background: 'var(--bg-3)', border: '1px solid var(--line)', borderRadius: 8, cursor: 'pointer' }}>
                <div style={{ display: 'flex', alignItems: 'start', gap: 8 }}>
                  <TaskCheckbox status={t.status} onClick={(e) => { e?.stopPropagation?.(); onToggle(t.id); }} />
                  <div style={{ flex: 1, fontSize: 12.5, color: 'var(--ink-0)' }}>{t.title}</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8, paddingLeft: 24 }}>
                  <PriorityPill p={t.priority} />
                  <span className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>{t.due}</span>
                  <div style={{ flex: 1 }} />
                  {a && <Avatar user={a} size={18} />}
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

function TaskDetailPanel({ t, onToggle, onJump }) {
  const D = window.KredeshData;
  const assignee = D.byId(D.users, t.assignee);
  const thread = D.threads.find(th => th.id === t.source);
  return (
    <aside style={{
      width: 340, flexShrink: 0,
      borderLeft: '1px solid var(--line)',
      background: 'var(--bg-1)',
      display: 'flex', flexDirection: 'column',
      overflow: 'hidden',
    }}>
      <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--line)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <PriorityPill p={t.priority} />
          {t.status === 'complete' && <Pill tone="ok">Complete</Pill>}
          {t.status === 'pending' && <Pill tone="blue">Pending</Pill>}
          {t.status === 'incomplete' && <Pill tone="bad">Incomplete</Pill>}
          <div style={{ flex: 1 }} />
          <button style={iconBtnLg} title="More"><Icons.more size={14} stroke="var(--ink-2)" /></button>
        </div>
        <h3 style={{ margin: 0, fontSize: 16, fontWeight: 600, lineHeight: 1.3 }}>{t.title}</h3>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <DetailRow label="Assignee" value={
          assignee ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7 }}>
            <Avatar user={assignee} size={20} /> {assignee.name.replace('You — ', '')}
          </span> : '—'
        } />
        <DetailRow label="Due" value={<span className="mono" style={{ color: t.overdue ? '#FCA5A5' : 'var(--ink-0)' }}>{t.due}</span>} />
        <DetailRow label="Source thread" value={
          thread ? <button onClick={onJump} style={{ background: 'none', border: 'none', padding: 0, color: '#93C5FD', fontSize: 12.5, cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: 2 }}>{thread.title}</button> : '—'
        } />
        <DetailRow label="Extracted entity" value={<span className="chip" style={{ pointerEvents: 'none' }}>{t.extractedFrom || '—'}</span>} />
        {t.completedAt && <DetailRow label="Completed" value={<span className="mono" style={{ color: '#86EFAC' }}>{t.completedAt}</span>} />}

        <div style={{ height: 1, background: 'var(--line)' }} />

        <div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 8 }}>Activity</div>
          <Activity items={[
            { who: 'Kredesh AI', icon: 'spark', body: 'Task created from message extraction.', at: '11:31' },
            { who: assignee?.name.split(' ')[0] || 'Maya', icon: 'user', body: 'Assigned to ' + (assignee?.name || 'you') + '.', at: '11:31' },
            ...(t.status === 'complete' ? [{ who: assignee?.name.split(' ')[0] || 'You', icon: 'check', body: 'Marked complete.', at: t.completedAt }] : []),
            ...(t.overdue ? [{ who: 'Kredesh AI', icon: 'warn', body: 'Task is overdue — escalation suggested.', at: '12:01' }] : []),
          ]} />
        </div>

        <div style={{ height: 1, background: 'var(--line)' }} />

        <div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 8 }}>Subtasks</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            <SubRow done text="Read the originating message" />
            <SubRow done={t.status === 'complete'} text="Take action in the field" />
            <SubRow text="Reply & log outcome in thread" />
          </div>
        </div>
      </div>

      <div style={{ padding: 14, borderTop: '1px solid var(--line)', display: 'flex', gap: 8 }}>
        {t.status === 'complete' ? (
          <Btn ghost style={{ flex: 1, justifyContent: 'center' }} onClick={onToggle}>Reopen task</Btn>
        ) : (
          <Btn primary style={{ flex: 1, justifyContent: 'center' }} icon={<Icons.check size={13} stroke="#fff" sw={2.2}/>} onClick={onToggle}>
            Mark complete
          </Btn>
        )}
        <Btn icon={<Icons.link size={13} />} onClick={onJump}>Thread</Btn>
      </div>
    </aside>
  );
}

function DetailRow({ label, value }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
      <span className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5 }}>{label}</span>
      <span style={{ fontSize: 12.5, color: 'var(--ink-0)', textAlign: 'right', maxWidth: '70%' }}>{value}</span>
    </div>
  );
}

function Activity({ items }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {items.map((it, i) => {
        const Ico = Icons[it.icon] || Icons.user;
        return (
          <div key={i} style={{ display: 'flex', gap: 9 }}>
            <div style={{ width: 22, height: 22, borderRadius: 6, background: 'var(--bg-3)', border: '1px solid var(--line)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
              <Ico size={12} stroke={it.icon === 'spark' ? '#93C5FD' : it.icon === 'check' ? '#86EFAC' : it.icon === 'warn' ? '#FCA5A5' : 'var(--ink-2)'} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, color: 'var(--ink-1)' }}><b style={{ color: 'var(--ink-0)' }}>{it.who}</b> {it.body}</div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', marginTop: 2 }}>{it.at}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function SubRow({ done, text }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '5px 8px', background: 'var(--bg-2)', borderRadius: 7 }}>
      <TaskCheckbox status={done ? 'complete' : 'pending'} />
      <span style={{ fontSize: 12.5, color: done ? 'var(--ink-3)' : 'var(--ink-0)', textDecoration: done ? 'line-through' : 'none' }}>{text}</span>
    </div>
  );
}

Object.assign(window, { TasksScreen });
