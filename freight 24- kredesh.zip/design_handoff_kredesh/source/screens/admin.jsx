// Admin dashboard — user management + invite flow
function AdminScreen() {
  const D = window.KredeshData;
  const [tab, setTab] = React.useState('users'); // users | invites | roles | audit
  const [employees, setEmployees] = React.useState(D.employees);
  const [showInvite, setShowInvite] = React.useState(false);
  const [search, setSearch] = React.useState('');
  const [selected, setSelected] = React.useState(new Set());
  const [roleFilter, setRoleFilter] = React.useState('all');

  const counts = {
    active: employees.filter(e => e.status === 'active').length,
    invited: employees.filter(e => e.status === 'invited').length,
    suspended: employees.filter(e => e.status === 'suspended').length,
  };

  const visible = employees.filter(e => {
    if (tab === 'invites' && e.status !== 'invited') return false;
    if (search && !(e.name + e.email + e.role + e.team).toLowerCase().includes(search.toLowerCase())) return false;
    if (roleFilter !== 'all' && e.role !== roleFilter) return false;
    return true;
  });

  const toggleAll = () => {
    if (selected.size === visible.length) setSelected(new Set());
    else setSelected(new Set(visible.map(e => e.id)));
  };
  const toggleOne = (id) => {
    const s = new Set(selected);
    s.has(id) ? s.delete(id) : s.add(id);
    setSelected(s);
  };

  const addInvite = (inv) => {
    setEmployees([{
      id: 'e' + (employees.length + 1),
      name: inv.name || inv.email.split('@')[0].replace('.', ' ').replace(/\b\w/g, c => c.toUpperCase()),
      email: inv.email,
      role: inv.role, team: inv.team,
      status: 'invited', lastActive: '—', joined: 'Invited just now', mfa: false,
    }, ...employees]);
    setShowInvite(false);
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
      <TopBar
        breadcrumb="Admin"
        title="User management"
        subtitle="Internal employees only. SCIM-synced from your IdP."
        right={
          <div style={{ display: 'flex', gap: 8 }}>
            <Btn size="sm" icon={<Icons.download size={13} />}>Export CSV</Btn>
            <Btn primary size="sm" icon={<Icons.plus size={13} />} onClick={() => setShowInvite(true)}>Invite user</Btn>
          </div>
        }
      />

      {/* Stat row */}
      <div style={{ padding: '14px 22px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, borderBottom: '1px solid var(--line)', background: 'var(--bg-1)' }}>
        <StatCard label="Active employees" value={counts.active} delta="+2 this week" tone="ok" />
        <StatCard label="Pending invites" value={counts.invited} delta="2 expire in 48h" tone="warn" />
        <StatCard label="Suspended" value={counts.suspended} delta="Review required" tone="bad" />
        <StatCard label="MFA enrolled" value={`${employees.filter(e => e.mfa && e.status === 'active').length}/${counts.active}`} delta="Goal: 100%" tone="brand" />
      </div>

      {/* Tabs */}
      <div style={{ padding: '0 22px', display: 'flex', alignItems: 'center', gap: 22, borderBottom: '1px solid var(--line)', background: 'var(--bg-1)' }}>
        {[
          { id: 'users', label: 'All users', count: employees.length },
          { id: 'invites', label: 'Invites', count: counts.invited },
          { id: 'roles', label: 'Roles & permissions' },
          { id: 'audit', label: 'Audit log' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: '12px 0', background: 'transparent', border: 'none',
            borderBottom: '2px solid', borderBottomColor: tab === t.id ? 'var(--brand)' : 'transparent',
            color: tab === t.id ? 'var(--ink-0)' : 'var(--ink-2)',
            fontSize: 13.5, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 7,
          }}>
            {t.label} {t.count != null && <span className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>{t.count}</span>}
          </button>
        ))}
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflow: 'auto', padding: '14px 22px', background: 'var(--bg-0)' }}>
        {(tab === 'users' || tab === 'invites') && (
          <React.Fragment>
            {/* Toolbar */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '6px 11px', background: 'var(--bg-2)', border: '1px solid var(--line)', borderRadius: 8, minWidth: 280 }}>
                <Icons.search size={13} stroke="var(--ink-3)" />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, email, team…"
                  style={{ flex: 1, background: 'none', border: 'none', color: 'var(--ink-0)', fontSize: 12.5, outline: 'none' }} />
              </div>
              <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)} style={{
                padding: '7px 10px', background: 'var(--bg-2)', border: '1px solid var(--line)',
                color: 'var(--ink-1)', borderRadius: 8, fontSize: 12.5,
              }}>
                <option value="all">All roles</option>
                {D.roles.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
              <Btn size="sm" icon={<Icons.filter size={13} />}>More filters</Btn>
              <div style={{ flex: 1 }} />
              {selected.size > 0 && (
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '0 6px' }}>
                  <span style={{ fontSize: 12, color: 'var(--ink-2)' }}>{selected.size} selected</span>
                  <Btn size="sm">Change role</Btn>
                  <Btn size="sm">Add to team</Btn>
                  <Btn size="sm" danger>Suspend</Btn>
                </div>
              )}
            </div>

            <div className="card" style={{ overflow: 'hidden' }}>
              <div style={{
                display: 'grid', gridTemplateColumns: '28px 1.5fr 1fr 130px 130px 110px 100px 28px',
                gap: 12, padding: '11px 14px',
                background: 'var(--bg-1)', borderBottom: '1px solid var(--line)',
                fontSize: 10.5, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.6, fontFamily: 'var(--mono)',
              }}>
                <input type="checkbox" checked={selected.size === visible.length && visible.length > 0} onChange={toggleAll} style={{ accentColor: 'var(--brand)' }} />
                <div>Name</div>
                <div>Role</div>
                <div>Team</div>
                <div>Last active</div>
                <div>Status</div>
                <div>MFA</div>
                <div></div>
              </div>
              {visible.map(e => (
                <div key={e.id} style={{
                  display: 'grid', gridTemplateColumns: '28px 1.5fr 1fr 130px 130px 110px 100px 28px',
                  gap: 12, padding: '11px 14px',
                  borderBottom: '1px solid var(--line)', alignItems: 'center',
                  background: selected.has(e.id) ? 'var(--bg-3)' : 'transparent',
                }}>
                  <input type="checkbox" checked={selected.has(e.id)} onChange={() => toggleOne(e.id)} style={{ accentColor: 'var(--brand)' }} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{
                      width: 30, height: 30, borderRadius: 999,
                      background: e.status === 'invited' ? 'var(--bg-3)' : avatarColor(e.id),
                      border: e.status === 'invited' ? '1px dashed var(--line-2)' : 'none',
                      display: 'grid', placeItems: 'center',
                      fontFamily: 'var(--mono)', fontSize: 11, fontWeight: 700,
                      color: e.status === 'invited' ? 'var(--ink-3)' : '#0B1220',
                    }}>
                      {initialsOf(e.name)}
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{e.name}</div>
                      <div className="mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>{e.email}</div>
                    </div>
                  </div>
                  <div style={{ fontSize: 12.5, color: 'var(--ink-1)' }}>{e.role}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--ink-2)' }}>{e.team}</div>
                  <div className="mono" style={{ fontSize: 11.5, color: 'var(--ink-2)' }}>{e.lastActive}</div>
                  <div>
                    {e.status === 'active' && <Pill tone="ok"><span className="dot" style={{ background: '#22C55E' }} /> Active</Pill>}
                    {e.status === 'invited' && <Pill tone="warn">Invited</Pill>}
                    {e.status === 'suspended' && <Pill tone="bad">Suspended</Pill>}
                  </div>
                  <div>
                    {e.mfa ? <Pill tone="ok"><Icons.check size={10} stroke="#86EFAC" sw={2.4}/></Pill> : <span style={{ fontSize: 11, color: 'var(--ink-3)' }}>—</span>}
                  </div>
                  <button style={iconBtnLg} title="More"><Icons.more size={14} stroke="var(--ink-2)" /></button>
                </div>
              ))}
            </div>
          </React.Fragment>
        )}

        {tab === 'roles' && <RolesPanel />}
        {tab === 'audit' && <AuditPanel />}
      </div>

      {showInvite && <InviteModal onClose={() => setShowInvite(false)} onInvite={addInvite} roles={D.roles} teams={D.teams} />}
    </div>
  );
}

function initialsOf(name) {
  return name.split(' ').slice(0, 2).map(s => s[0]).join('').toUpperCase();
}
function avatarColor(id) {
  const palette = ['#3B82F6','#22D3EE','#A78BFA','#F472B6','#22C55E','#F59E0B','#EF4444','#10B981'];
  const idx = (id.charCodeAt(id.length - 1) + parseInt(id.slice(1) || '0', 10)) % palette.length;
  return palette[idx];
}

function InviteModal({ onClose, onInvite, roles, teams }) {
  const [step, setStep] = React.useState(1);
  const [emails, setEmails] = React.useState('owen.tahan@kredesh.co');
  const [role, setRole] = React.useState('Dispatcher');
  const [team, setTeam] = React.useState('Operations');
  const [perms, setPerms] = React.useState({
    inbox: true, tasks: true, shipments: true, reports: false, admin: false,
  });
  const [welcome, setWelcome] = React.useState('Welcome to Kredesh — we built this so you spend less time in DMs and more time moving freight. Holler if anything is wonky.');

  const emailList = emails.split(/[\s,;]+/).filter(Boolean);

  const send = () => {
    emailList.forEach(em => onInvite({ email: em, role, team }));
  };

  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, background: 'rgba(7,11,20,0.72)',
      backdropFilter: 'blur(4px)', display: 'grid', placeItems: 'center', zIndex: 50, padding: 20,
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        width: 'min(640px, 100%)',
        background: 'var(--bg-1)', border: '1px solid var(--line-2)',
        borderRadius: 16, overflow: 'hidden',
        boxShadow: '0 30px 80px rgba(0,0,0,0.5)',
      }}>
        {/* header */}
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--brand-soft)', border: '1px solid rgba(59,130,246,0.4)', display: 'grid', placeItems: 'center' }}>
            <Icons.mail size={15} stroke="#93C5FD" />
          </div>
          <div style={{ flex: 1 }}>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600 }}>Invite teammates to Kredesh</h3>
            <div className="mono" style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>Step {step} of 3</div>
          </div>
          <button onClick={onClose} style={{ ...iconBtnLg, fontSize: 16 }}>✕</button>
        </div>

        {/* progress */}
        <div style={{ display: 'flex', gap: 4, padding: '0 20px', marginTop: 14 }}>
          {[1, 2, 3].map(s => (
            <div key={s} style={{
              flex: 1, height: 3, borderRadius: 999,
              background: s <= step ? 'var(--brand)' : 'var(--bg-3)',
            }} />
          ))}
        </div>

        <div style={{ padding: '20px 22px 8px', minHeight: 320 }}>
          {step === 1 && (
            <React.Fragment>
              <label style={{ display: 'block', marginBottom: 14 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink-1)', marginBottom: 7 }}>Work emails</div>
                <textarea value={emails} onChange={e => setEmails(e.target.value)}
                  rows={3}
                  placeholder="owen@kredesh.co, rosa@kredesh.co"
                  style={{
                    width: '100%', padding: '10px 12px',
                    background: 'var(--bg-2)', border: '1px solid var(--line-2)',
                    borderRadius: 9, color: 'var(--ink-0)', fontSize: 13,
                    fontFamily: 'var(--mono)', outline: 'none', resize: 'vertical',
                  }} />
                <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 6 }}>
                  Separate by comma or new line. Only <span className="mono" style={{ color: 'var(--ink-1)' }}>@kredesh.co</span> domains will be accepted.
                </div>
              </label>
              {emailList.length > 0 && (
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 14 }}>
                  {emailList.map((em, i) => (
                    <span key={i} className="chip" style={{ pointerEvents: 'none' }}>
                      <Icons.mail size={11} stroke="#93C5FD" /> {em}
                    </span>
                  ))}
                </div>
              )}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 6 }}>
                <SelectField label="Role" value={role} onChange={setRole} options={roles} />
                <SelectField label="Team" value={team} onChange={setTeam} options={teams} />
              </div>
            </React.Fragment>
          )}

          {step === 2 && (
            <React.Fragment>
              <div style={{ marginBottom: 14, fontSize: 12.5, color: 'var(--ink-2)' }}>
                Choose what these invitees can do. Defaults match their role; tweak as needed.
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <PermRow id="inbox" perms={perms} setPerms={setPerms} icon="inbox" label="Inbox & messaging" desc="Send and receive messages in assigned threads." />
                <PermRow id="tasks" perms={perms} setPerms={setPerms} icon="tasks" label="Tasks" desc="View, claim, and mark tasks complete." />
                <PermRow id="shipments" perms={perms} setPerms={setPerms} icon="truck" label="Shipments" desc="Read & edit shipment records, attach docs." />
                <PermRow id="reports" perms={perms} setPerms={setPerms} icon="chart" label="Reports" desc="Access operational analytics and exports." />
                <PermRow id="admin" perms={perms} setPerms={setPerms} icon="shield" label="Admin" desc="Manage users, roles, billing. Grant carefully." danger />
              </div>
              <div style={{ marginTop: 16, padding: '10px 12px', background: 'var(--bg-2)', border: '1px solid var(--line)', borderRadius: 9, display: 'flex', gap: 9, alignItems: 'flex-start' }}>
                <Icons.shield size={14} stroke="#67E8F9" />
                <div style={{ fontSize: 11.5, color: 'var(--ink-2)', lineHeight: 1.5 }}>
                  Invitees must enroll in <b>two-factor authentication</b> within 7 days or their account is auto-suspended.
                </div>
              </div>
            </React.Fragment>
          )}

          {step === 3 && (
            <React.Fragment>
              <label style={{ display: 'block', marginBottom: 14 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink-1)', marginBottom: 7 }}>Personal note (optional)</div>
                <textarea value={welcome} onChange={e => setWelcome(e.target.value)} rows={4}
                  style={{
                    width: '100%', padding: '10px 12px',
                    background: 'var(--bg-2)', border: '1px solid var(--line-2)',
                    borderRadius: 9, color: 'var(--ink-0)', fontSize: 13,
                    outline: 'none', resize: 'vertical', lineHeight: 1.5,
                  }} />
              </label>

              <div className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 8 }}>Preview</div>
              <div style={{
                padding: 14, background: '#0A0F1C', border: '1px solid var(--line)', borderRadius: 10,
                fontSize: 12.5, color: 'var(--ink-1)', lineHeight: 1.55,
              }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: 'var(--ink-0)', marginBottom: 4 }}>You're invited to Kredesh</div>
                <div style={{ color: 'var(--ink-3)', fontSize: 11, marginBottom: 12 }}>From Avery Chen · Ops Manager</div>
                <div style={{ marginBottom: 12 }}>{welcome}</div>
                <div style={{ display: 'flex', gap: 10, marginBottom: 12, fontSize: 11.5, color: 'var(--ink-2)' }}>
                  <span><b style={{ color: 'var(--ink-1)' }}>Role:</b> {role}</span>
                  <span><b style={{ color: 'var(--ink-1)' }}>Team:</b> {team}</span>
                </div>
                <div style={{ display: 'inline-block', padding: '8px 14px', background: 'var(--brand)', color: '#fff', borderRadius: 7, fontSize: 12.5, fontWeight: 600 }}>
                  Accept invite →
                </div>
              </div>
            </React.Fragment>
          )}
        </div>

        <div style={{ padding: '14px 20px', borderTop: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 10 }}>
          {step > 1 && <Btn ghost onClick={() => setStep(step - 1)}>Back</Btn>}
          <div style={{ flex: 1 }} />
          <Btn ghost onClick={onClose}>Cancel</Btn>
          {step < 3 ? (
            <Btn primary onClick={() => setStep(step + 1)} icon={<Icons.arrow size={13} />}>Continue</Btn>
          ) : (
            <Btn primary onClick={send} icon={<Icons.send size={13} />}>Send {emailList.length} {emailList.length === 1 ? 'invite' : 'invites'}</Btn>
          )}
        </div>
      </div>
    </div>
  );
}

function SelectField({ label, value, onChange, options }) {
  return (
    <label style={{ display: 'block' }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ink-1)', marginBottom: 7 }}>{label}</div>
      <select value={value} onChange={e => onChange(e.target.value)} style={{
        width: '100%', padding: '10px 12px',
        background: 'var(--bg-2)', border: '1px solid var(--line-2)',
        borderRadius: 9, color: 'var(--ink-0)', fontSize: 13, outline: 'none',
      }}>
        {options.map(o => <option key={o} value={o}>{o}</option>)}
      </select>
    </label>
  );
}

function PermRow({ id, perms, setPerms, icon, label, desc, danger }) {
  const Ico = Icons[icon];
  const on = perms[id];
  return (
    <label style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '11px 13px',
      background: 'var(--bg-2)', border: '1px solid', borderColor: on && danger ? 'rgba(239,68,68,0.4)' : 'var(--line)',
      borderRadius: 9, cursor: 'pointer',
    }}>
      <div style={{
        width: 28, height: 28, borderRadius: 7,
        background: danger ? 'var(--bad-soft)' : 'var(--bg-3)',
        border: '1px solid', borderColor: danger ? 'rgba(239,68,68,0.3)' : 'var(--line)',
        display: 'grid', placeItems: 'center',
      }}>
        <Ico size={14} stroke={danger ? '#FCA5A5' : 'var(--ink-1)'} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--ink-0)' }}>{label}</div>
        <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{desc}</div>
      </div>
      <button type="button" onClick={() => setPerms({ ...perms, [id]: !on })} style={{
        width: 34, height: 20, padding: 2, borderRadius: 999,
        background: on ? (danger ? 'var(--bad)' : 'var(--brand)') : 'var(--bg-3)',
        border: '1px solid', borderColor: on ? 'transparent' : 'var(--line-2)',
        position: 'relative', cursor: 'pointer',
      }}>
        <span style={{
          position: 'absolute', top: 2, left: on ? 16 : 2,
          width: 14, height: 14, borderRadius: 999, background: '#fff',
          transition: 'left .15s ease',
        }} />
      </button>
    </label>
  );
}

function RolesPanel() {
  const D = window.KredeshData;
  const matrix = [
    { perm: 'View inbox',           Ops: true, Disp: true, Brk: true, WH: true, Drv: true, CS: true, Adm: true },
    { perm: 'Send messages',        Ops: true, Disp: true, Brk: true, WH: true, Drv: true, CS: true, Adm: true },
    { perm: 'Create / edit tasks',  Ops: true, Disp: true, Brk: true, WH: 'self', Drv: 'self', CS: true, Adm: true },
    { perm: 'View shipments',       Ops: true, Disp: true, Brk: true, WH: true, Drv: 'self', CS: true, Adm: true },
    { perm: 'Edit shipment fields', Ops: true, Disp: true, Brk: 'rate', WH: 'dims', Drv: false, CS: false, Adm: true },
    { perm: 'Access reports',       Ops: true, Disp: false, Brk: false, WH: false, Drv: false, CS: false, Adm: true },
    { perm: 'Invite & manage users',Ops: false, Disp: false, Brk: false, WH: false, Drv: false, CS: false, Adm: true },
    { perm: 'Edit billing & rates', Ops: false, Disp: false, Brk: false, WH: false, Drv: false, CS: false, Adm: true },
  ];
  const cols = ['Ops', 'Disp', 'Brk', 'WH', 'Drv', 'CS', 'Adm'];
  const cell = (v) => {
    if (v === true) return <Icons.check size={13} stroke="#22C55E" sw={2.4}/>;
    if (v === false) return <span style={{ color: 'var(--ink-4)' }}>—</span>;
    return <span className="mono" style={{ fontSize: 10, color: '#FCD34D' }}>{v}</span>;
  };
  return (
    <div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 14 }}>
        <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600 }}>Permission matrix</h3>
        <Btn size="sm" ghost icon={<Icons.plus size={13} />}>New role</Btn>
      </div>
      <div className="card" style={{ overflow: 'hidden' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr repeat(7, 1fr)', gap: 8, padding: '11px 14px', background: 'var(--bg-1)', borderBottom: '1px solid var(--line)' }}>
          <div className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5 }}>Permission</div>
          {cols.map(c => <div key={c} className="mono" style={{ fontSize: 10, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: 0.5, textAlign: 'center' }}>{c}</div>)}
        </div>
        {matrix.map((row, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '1.4fr repeat(7, 1fr)', gap: 8, padding: '11px 14px', borderBottom: '1px solid var(--line)', alignItems: 'center' }}>
            <div style={{ fontSize: 12.5, color: 'var(--ink-1)' }}>{row.perm}</div>
            {cols.map(c => <div key={c} style={{ textAlign: 'center' }}>{cell(row[c])}</div>)}
          </div>
        ))}
      </div>
      <div style={{ marginTop: 14, padding: '10px 14px', background: 'var(--bg-2)', border: '1px dashed var(--line-2)', borderRadius: 9, fontSize: 11.5, color: 'var(--ink-3)' }}>
        Codes: <span style={{ color: '#FCD34D' }}>self</span> = own records only · <span style={{ color: '#FCD34D' }}>rate</span> = rate fields only · <span style={{ color: '#FCD34D' }}>dims</span> = pallets/weight only.
      </div>
    </div>
  );
}

function AuditPanel() {
  const log = [
    { at: '11:43', who: 'Avery Chen', action: 'invited owen.tahan@kredesh.co as Dispatcher', kind: 'invite' },
    { at: '10:21', who: 'Maya Okafor', action: 'promoted Diego Salinas → Dispatcher Lead', kind: 'role' },
    { at: 'Yesterday 17:02', who: 'System', action: 'auto-suspended Beatrice Yu — 12 days idle', kind: 'auto' },
    { at: 'Yesterday 12:11', who: 'Maya Okafor', action: 'changed permission Edit shipment fields → Dispatcher (true)', kind: 'perm' },
    { at: 'Mon 09:42', who: 'Tomás Beltrán', action: 'enrolled MFA via authenticator app', kind: 'mfa' },
    { at: 'Mon 08:30', who: 'System', action: 'SCIM sync — 0 added, 1 disabled (Rebecca H.)', kind: 'auto' },
    { at: 'Fri 16:48', who: 'Avery Chen', action: 'exported user CSV (10 rows)', kind: 'export' },
  ];
  return (
    <div>
      <div style={{ marginBottom: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
        <h3 style={{ margin: 0, fontSize: 15, fontWeight: 600 }}>Audit log</h3>
        <span style={{ fontSize: 12, color: 'var(--ink-3)' }}>Append-only · last 90 days</span>
        <div style={{ flex: 1 }} />
        <Btn size="sm" icon={<Icons.download size={13} />}>Export</Btn>
      </div>
      <div className="card" style={{ overflow: 'hidden' }}>
        {log.map((l, i) => (
          <div key={i} style={{ display: 'flex', gap: 14, padding: '12px 14px', borderBottom: i < log.length - 1 ? '1px solid var(--line)' : 'none' }}>
            <span className="mono" style={{ fontSize: 11, color: 'var(--ink-3)', width: 140, flexShrink: 0 }}>{l.at}</span>
            <span style={{ fontSize: 12.5, color: 'var(--ink-0)', fontWeight: 600, width: 140, flexShrink: 0 }}>{l.who}</span>
            <span style={{ flex: 1, fontSize: 12.5, color: 'var(--ink-1)' }}>{l.action}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { AdminScreen });
