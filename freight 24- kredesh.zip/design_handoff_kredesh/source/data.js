// Seed data for Kredesh Logistics OS prototype
window.KredeshData = (() => {
  const users = [
    { id: 'u1', name: 'Maya Okafor',     role: 'Ops Manager',     team: 'Operations', status: 'online',  avatar: '#3B82F6', initials: 'MO' },
    { id: 'u2', name: 'Diego Salinas',   role: 'Dispatcher',      team: 'Operations', status: 'online',  avatar: '#22D3EE', initials: 'DS' },
    { id: 'u3', name: 'Priya Raghavan',  role: 'Freight Broker',  team: 'Brokerage',  status: 'online',  avatar: '#A78BFA', initials: 'PR' },
    { id: 'u4', name: 'Tomás Beltrán',   role: 'Warehouse Lead',  team: 'Warehouse',  status: 'away',    avatar: '#F472B6', initials: 'TB' },
    { id: 'u5', name: 'Aiyana Whitehorse',role:'Driver — T‑442',  team: 'Fleet',      status: 'online',  avatar: '#22C55E', initials: 'AW' },
    { id: 'u6', name: 'Jonas Lindqvist', role: 'Carrier — Northbound Freight', team: 'External', status: 'offline', avatar: '#F59E0B', initials: 'JL' },
    { id: 'u7', name: 'Hana Park',       role: 'Customer Support',team: 'Support',    status: 'online',  avatar: '#EF4444', initials: 'HP' },
    { id: 'u8', name: 'Wesley Kibet',    role: 'Yard Coordinator',team: 'Warehouse',  status: 'away',    avatar: '#10B981', initials: 'WK' },
    { id: 'me', name: 'You — Avery Chen', role:'Ops Manager',     team: 'Operations', status: 'online',  avatar: '#3B82F6', initials: 'AC', isMe: true, isAdmin: true },
  ];

  const channels = [
    { id: 'c1', name: 'ops-dispatch',     kind: 'channel', unread: 3, members: 12 },
    { id: 'c2', name: 'warehouse-floor',  kind: 'channel', unread: 0, members: 18 },
    { id: 'c3', name: 'brokers-room',     kind: 'channel', unread: 7, members: 9 },
    { id: 'c4', name: 'incidents',        kind: 'channel', unread: 1, members: 24, alert: true },
    { id: 'c5', name: 'crossdock-pdx',    kind: 'channel', unread: 0, members: 6 },
  ];

  // Direct/carrier threads — primary entry points
  const threads = [
    {
      id: 't1',
      title: 'Northbound Freight — Load #PRO 778‑441920',
      preview: 'Pickup confirmed at Tualatin DC, 2 hr early. Driver wheels up at 14:20…',
      with: 'u6',
      kind: 'carrier',
      unread: 2,
      lastAt: '11:42',
      tags: ['load', 'pickup'],
      pinned: true,
    },
    {
      id: 't2',
      title: 'Aiyana Whitehorse — T‑442 reefer',
      preview: 'Set point reading -2°F vs requested -10°F. Verifying sensor before pulling…',
      with: 'u5',
      kind: 'driver',
      unread: 1,
      lastAt: '11:30',
      tags: ['reefer', 'urgent'],
    },
    {
      id: 't3',
      title: 'Tomás — dock door 14 inbound',
      preview: 'Trailer T‑881 backed in. Seal intact. Starting unload of 22 pallets…',
      with: 'u4',
      kind: 'warehouse',
      unread: 0,
      lastAt: '10:58',
      tags: ['inbound', 'pod'],
    },
    {
      id: 't4',
      title: 'Priya — quote request, Memphis → Denver',
      preview: '34 pallets dry van, pickup window Wed 06:00–10:00. Need rate by EOD…',
      with: 'u3',
      kind: 'broker',
      unread: 0,
      lastAt: 'Yesterday',
      tags: ['quote'],
    },
    {
      id: 't5',
      title: '#ops-dispatch',
      preview: 'Diego: 3 trucks waiting on yard assignment — anyone available?',
      kind: 'channel',
      unread: 3,
      lastAt: 'Yesterday',
      channel: 'c1',
    },
    {
      id: 't6',
      title: '#incidents',
      preview: 'ALERT: I‑84 closure mile 53 EB — reroute via OR‑35 for affected loads',
      kind: 'channel',
      unread: 1,
      lastAt: '08:14',
      channel: 'c4',
      alert: true,
    },
    {
      id: 't7',
      title: 'Hana — customer escalation, Wellspring Foods',
      preview: 'Customer asking for ETA on PO 88231. Last scan was Tuesday 22:00…',
      with: 'u7',
      kind: 'dm',
      unread: 0,
      lastAt: 'Mon',
      tags: ['customer'],
    },
  ];

  // Thread t1 — full message log with extracted entities
  const t1Messages = [
    {
      id: 'm1', from: 'u6', at: '11:21',
      // Each segment is either plain text or a highlight
      segments: [
        { t: 'Hey Avery — pickup confirmed at ' },
        { t: 'Tualatin DC (7800 SW Durham Rd, Tigard OR 97224)', hl: 'address', entity: 'address-pickup' },
        { t: '. Driver wheels up by ' },
        { t: '14:20 PT', hl: 'time', entity: 'time-pickup' },
        { t: '. Equipment: ' },
        { t: '53′ dry van', hl: 'cyan', entity: 'equipment' },
        { t: '.' },
      ],
    },
    {
      id: 'm2', from: 'me', at: '11:23',
      segments: [
        { t: 'Confirmed. What\'s the load count and weight?' },
      ],
    },
    {
      id: 'm3', from: 'u6', at: '11:31',
      segments: [
        { t: 'Load #' },
        { t: 'PRO 778‑441920', hl: 'cyan', entity: 'pro' },
        { t: ' — ' },
        { t: '24 pallets', hl: 'cyan', entity: 'pallets' },
        { t: ', ' },
        { t: '38,420 lbs', hl: 'cyan', entity: 'weight' },
        { t: '. Drop at ' },
        { t: 'Cascade Cold Storage, 1450 N Marine Dr, Portland OR 97217', hl: 'address', entity: 'address-drop' },
        { t: '. Delivery window ' },
        { t: 'Wed 06:00–10:00 PT', hl: 'time', entity: 'time-drop' },
        { t: '.' },
      ],
      attachments: [
        { kind: 'doc', name: 'BOL_778441920.pdf', size: '212 KB', type: 'BOL' },
      ],
    },
    {
      id: 'm4', from: 'me', at: '11:34',
      segments: [
        { t: 'Good. POD required on delivery — driver should also grab a temp log.' },
      ],
    },
    {
      id: 'm5', from: 'u6', at: '11:42',
      segments: [
        { t: 'Copy. One thing — ' },
        { t: 'detention may run 1.5 hrs', hl: 'warn', entity: 'detention' },
        { t: ' at Cascade if dock 4 isn\'t free. Will update on approach.' },
      ],
      voice: { dur: '0:42', waveform: [3,5,8,12,9,14,18,15,10,7,11,16,20,14,9,6,8,12,15,10,6,4,7,11,8,5,3,2,4,6] },
    },
  ];

  // Tasks auto-extracted from messages
  const tasks = [
    { id: 'tk1', title: 'Confirm pickup at Tualatin DC', source: 't1', sourceMsg: 'm1', status: 'complete', assignee: 'me', due: 'Today 14:00', priority: 'med', extractedFrom: 'PRO 778‑441920', completedAt: '11:23' },
    { id: 'tk2', title: 'Log 24 pallets / 38,420 lbs to shipment', source: 't1', sourceMsg: 'm3', status: 'complete', assignee: 'me', due: 'Today', priority: 'low', extractedFrom: 'PRO 778‑441920', completedAt: '11:33' },
    { id: 'tk3', title: 'Verify reefer set point on T‑442', source: 't2', status: 'pending', assignee: 'u5', due: 'Today 12:30', priority: 'high', extractedFrom: 'T‑442 reefer' },
    { id: 'tk4', title: 'Reroute affected loads via OR‑35', source: 't6', status: 'pending', assignee: 'u2', due: 'Today 13:00', priority: 'high', extractedFrom: 'I‑84 closure' },
    { id: 'tk5', title: 'Capture POD + temp log @ Cascade Cold Storage', source: 't1', sourceMsg: 'm4', status: 'pending', assignee: 'u5', due: 'Wed 10:00', priority: 'med', extractedFrom: 'PRO 778‑441920' },
    { id: 'tk6', title: 'Get rate quote, Memphis → Denver (34 plt)', source: 't4', status: 'pending', assignee: 'u3', due: 'Today EOD', priority: 'med', extractedFrom: 'quote request' },
    { id: 'tk7', title: 'Resolve dock door 14 seal discrepancy', source: 't3', status: 'incomplete', assignee: 'u4', due: 'Yesterday 18:00', priority: 'high', extractedFrom: 'Trailer T‑881', overdue: true },
    { id: 'tk8', title: 'Update Wellspring Foods on PO 88231 ETA', source: 't7', status: 'incomplete', assignee: 'u7', due: 'Mon 16:00', priority: 'high', extractedFrom: 'PO 88231', overdue: true },
    { id: 'tk9', title: 'Send detention notice (1.5h) — Cascade', source: 't1', sourceMsg: 'm5', status: 'pending', assignee: 'me', due: 'On arrival', priority: 'low', extractedFrom: 'PRO 778‑441920' },
    { id: 'tk10', title: 'Yard assignment for 3 waiting trucks', source: 't5', status: 'complete', assignee: 'u2', due: 'Yesterday', priority: 'med', extractedFrom: 'yard backlog', completedAt: 'Yesterday 16:40' },
    { id: 'tk11', title: 'Upload signed BOL to PRO 778‑441920', source: 't1', sourceMsg: 'm3', status: 'complete', assignee: 'me', due: 'Today', priority: 'low', completedAt: '11:35' },
    { id: 'tk12', title: 'Confirm hazmat placards on T‑619', source: 't1', status: 'pending', assignee: 'u4', due: 'Today 15:00', priority: 'med', extractedFrom: 'PRO 778‑441920' },
  ];

  // Shipments / loads
  const shipments = [
    { id: 's1', pro: 'PRO 778‑441920', customer: 'Wellspring Foods', origin: 'Tualatin, OR', dest: 'Portland, OR', miles: 18, equip: '53′ dry van', weight: '38,420 lbs', pallets: 24, status: 'in_transit', eta: 'Today 13:48', driver: 'Aiyana Whitehorse', carrier: 'Northbound Freight', rate: '$1,240', tempSet: null, progress: 0.62 },
    { id: 's2', pro: 'PRO 992‑118044', customer: 'Cascade Cold Storage', origin: 'Reno, NV', dest: 'Portland, OR', miles: 569, equip: '53′ reefer (-10°F)', weight: '41,200 lbs', pallets: 22, status: 'at_pickup', eta: 'Wed 06:00', driver: '—', carrier: 'PolarLine LTL', rate: '$2,980', tempSet: '-10°F', progress: 0.08 },
    { id: 's3', pro: 'PRO 451‑238110', customer: 'Pacific Bolt & Fastener', origin: 'Memphis, TN', dest: 'Denver, CO', miles: 1042, equip: '48′ flatbed', weight: '44,100 lbs', pallets: 34, status: 'quoting', eta: '—', driver: '—', carrier: 'TBD', rate: '$3,420 (quote)', tempSet: null, progress: 0 },
    { id: 's4', pro: 'PRO 110‑772083', customer: 'Greenline Produce', origin: 'Salinas, CA', dest: 'Seattle, WA', miles: 953, equip: '53′ reefer (34°F)', weight: '39,800 lbs', pallets: 26, status: 'delivered', eta: 'Mon 09:12', driver: 'Mateo R.', carrier: 'Coastal Express', rate: '$3,140', tempSet: '34°F', progress: 1 },
    { id: 's5', pro: 'PRO 882‑009417', customer: 'Northwest Brewing Co', origin: 'Yakima, WA', dest: 'Portland, OR', miles: 197, equip: '53′ dry van', weight: '36,500 lbs', pallets: 30, status: 'delayed', eta: 'Today 18:30', driver: 'Sven O.', carrier: 'Cascade Lines', rate: '$1,420', tempSet: null, progress: 0.41, alert: 'I‑84 closure' },
    { id: 's6', pro: 'PRO 663‑551082', customer: 'Trailhead Outdoor', origin: 'Boise, ID', dest: 'Portland, OR', miles: 432, equip: '28′ pup', weight: '12,400 lbs', pallets: 8, status: 'in_transit', eta: 'Today 21:10', driver: 'Linh T.', carrier: 'BlueRidge Carriers', rate: '$840', tempSet: null, progress: 0.78 },
  ];

  const notifications = [
    { id: 'n1', kind: 'alert', title: 'I‑84 closure affecting PRO 882‑009417', body: 'Eastbound mile 53. Reroute suggested via OR‑35. Driver Sven O. notified.', at: '08:14', read: false },
    { id: 'n2', kind: 'task',  title: 'Task assigned: Verify reefer set point on T‑442', body: 'Auto-extracted from message in “Aiyana Whitehorse — T‑442 reefer”.', at: '09:02', read: false },
    { id: 'n3', kind: 'doc',   title: 'BOL uploaded — PRO 778‑441920', body: 'Jonas Lindqvist attached BOL_778441920.pdf (212 KB).', at: '11:31', read: false },
    { id: 'n4', kind: 'task',  title: '2 tasks overdue', body: 'Trailer T‑881 seal discrepancy · Wellspring PO 88231 ETA update', at: 'Today', read: false },
    { id: 'n5', kind: 'mention', title: '@you in #incidents', body: 'Diego mentioned you while dispatching reroutes.', at: 'Yesterday', read: true },
    { id: 'n6', kind: 'doc',   title: 'POD captured — PRO 110‑772083', body: 'Mateo R. signed delivery at Greenline Produce, 09:12.', at: 'Mon', read: true },
  ];

  // Admin: invited / active employees
  const employees = [
    { id: 'e1', name: 'Maya Okafor',      email: 'maya@kredesh.co',      role: 'Ops Manager',     team: 'Operations', status: 'active',   lastActive: '2 min ago',  joined: 'Mar 2024', mfa: true },
    { id: 'e2', name: 'Diego Salinas',    email: 'diego@kredesh.co',     role: 'Dispatcher',      team: 'Operations', status: 'active',   lastActive: '8 min ago',  joined: 'Aug 2024', mfa: true },
    { id: 'e3', name: 'Priya Raghavan',   email: 'priya@kredesh.co',     role: 'Freight Broker',  team: 'Brokerage',  status: 'active',   lastActive: '32 min ago', joined: 'Jan 2025', mfa: false },
    { id: 'e4', name: 'Tomás Beltrán',    email: 'tomas@kredesh.co',     role: 'Warehouse Lead',  team: 'Warehouse',  status: 'active',   lastActive: '1 hr ago',   joined: 'Feb 2023', mfa: true },
    { id: 'e5', name: 'Aiyana Whitehorse',email: 'aiyana@kredesh.co',    role: 'Driver',          team: 'Fleet',      status: 'active',   lastActive: 'Just now',   joined: 'Nov 2024', mfa: true },
    { id: 'e6', name: 'Hana Park',        email: 'hana@kredesh.co',      role: 'Customer Support',team: 'Support',    status: 'active',   lastActive: '4 hr ago',   joined: 'Jul 2024', mfa: true },
    { id: 'e7', name: 'Wesley Kibet',     email: 'wesley@kredesh.co',    role: 'Yard Coordinator',team: 'Warehouse',  status: 'active',   lastActive: 'Yesterday',  joined: 'Sep 2024', mfa: false },
    { id: 'e8', name: 'Owen Tahan',       email: 'owen@kredesh.co',      role: 'Dispatcher',      team: 'Operations', status: 'invited',  lastActive: '—',          joined: 'Invited 2d ago', mfa: false },
    { id: 'e9', name: 'Rosa Petrenko',    email: 'rosa@kredesh.co',      role: 'Driver',          team: 'Fleet',      status: 'invited',  lastActive: '—',          joined: 'Invited 5h ago', mfa: false },
    { id: 'e10', name: 'Beatrice Yu',     email: 'b.yu@kredesh.co',      role: 'Ops Manager',     team: 'Operations', status: 'suspended',lastActive: '12 d ago',   joined: 'May 2022', mfa: true },
  ];

  const teams = ['Operations', 'Brokerage', 'Warehouse', 'Fleet', 'Support', 'Finance'];
  const roles = ['Ops Manager', 'Dispatcher', 'Freight Broker', 'Warehouse Lead', 'Yard Coordinator', 'Driver', 'Customer Support', 'Admin'];

  return {
    users, channels, threads, t1Messages, tasks, shipments, notifications,
    employees, teams, roles,
    byId: (arr, id) => arr.find(x => x.id === id),
  };
})();
